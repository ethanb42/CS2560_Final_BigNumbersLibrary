var searchData=
[
  ['bignumbers',['BigNumbers',['../class_big_numbers.html#af3dd82883f10f3473ac83280f26b0ad8',1,'BigNumbers::BigNumbers()'],['../class_big_numbers.html#abcb4c1ae5c9f11efda8355d695bca34c',1,'BigNumbers::BigNumbers(int number)'],['../class_big_numbers.html#ae5a4140c0f1bf6238bf7f3f5b6d362a0',1,'BigNumbers::BigNumbers(BigNumbers &amp;big)'],['../class_big_numbers.html#a225709f0432fc601fcc4937211cd62f4',1,'BigNumbers::BigNumbers(std::string s)']]]
];
