var searchData=
[
  ['subtracttwonegatives',['subtractTwoNegatives',['../class_big_numbers.html#a8c22955aba5e0fdd914771fe8bbfb027',1,'BigNumbers']]],
  ['subtracttwopositives',['subtractTwoPositives',['../class_big_numbers.html#ac836df7898e5778aaefd493de405a357',1,'BigNumbers']]]
];
